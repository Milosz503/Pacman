colors = {
	
	{r = 255, g = 255, b = 255},
	{r = 255, g = 0, b = 0},
	{r = 0, g = 255, b = 0},
	{r = 0, g = 0, b = 255},
	{r = 0, g = 255, b = 255},
	{r = 255, g = 0, b = 255},
	{r = 255, g = 255, b = 0},
	{r = 128, g = 128, b = 128},
	
}

return {
	white = 0;
	red = 1;
	green = 2;
	blue = 3;
	yellow = 4;
	grey = 5;
	darkgrey = 6;
	lightgrey = 7;
}


